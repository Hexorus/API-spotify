import static org.junit.jupiter.api.Assertions.assertEquals;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.intuit.karate.Results;
import com.intuit.karate.Runner;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import utils.XrayUtil;

class TestRunner {

    @BeforeAll
    static void sincronizar() throws Exception {

        XrayUtil.cargarVariablesDeAmbiente();
        XrayUtil.sincronizarFetaures();
        //XrayUtil.marcarCasosAutomatizados();

    }

    @AfterAll
    static void enviarReporte() throws Exception {
        XrayUtil.unficarReportesJson();
        XrayUtil.generarInfoJson();
        XrayUtil.enviarReporte();
        System.out.println("SINCRONIZACION TERMINADA");
    }

    /*RUN ALL TESTS*/
    @Test
    void testRunner() {
        Results results = Runner.path("classpath:taller")
                .outputCucumberJson(true)
                .tags("~@ignore")
                .parallel(0);
        generateReport(results.getReportDir());
        assertEquals(0, results.getFailCount(), results.getErrorMessages());
    }

    public static void generateReport(String karateOutputPath) {
        Collection<File> jsonFiles = FileUtils.listFiles(new File(karateOutputPath), new String[]{"json"}, true);
        List<String> jsonPaths = new ArrayList<>(jsonFiles.size());
        jsonFiles.forEach(file -> jsonPaths.add(file.getAbsolutePath()));
        Configuration config = new Configuration(new File("target"), "taller");
        ReportBuilder reportBuilder = new ReportBuilder(jsonPaths, config);
        reportBuilder.generateReports();
    }
}
