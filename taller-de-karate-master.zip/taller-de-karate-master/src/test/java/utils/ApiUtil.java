package utils;

import javax.net.ssl.KeyManager;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;

import java.net.URL;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class ApiUtil implements X509TrustManager {

    /**
     *
     * @param uri Url del servicio
     * @param requestBody jsonbody requerido por el servicio
     * @return responseBody que devuelve el servicio
     * @throws Exception
     */
    public static String post(String uri, String requestBody) throws Exception {
        String responseBody = null;
        List<String> response = new ArrayList<String>();
        try {
            // configure the SSLContext with a TrustManager
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(new KeyManager[0], new TrustManager[]{new ApiUtil()}, new SecureRandom());
            SSLContext.setDefault(ctx);

            // Prepare request
            URL url = new URL(uri);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);
            OutputStream output = connection.getOutputStream();
            output.write(requestBody.getBytes());
            output.flush();
            output.close();

            //Print Response
            int status = connection.getResponseCode();
            if (status == 200) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(
                        connection.getInputStream()));
                String line = null;
                while ((line = reader.readLine()) != null) {
                    response.add(line);
                }
                reader.close();
                connection.disconnect();
            } else {
                System.out.println(new BufferedReader(new InputStreamReader(connection.getErrorStream())).lines().collect(Collectors.joining()));
                throw new IOException("Server returned non-OK status: " + status);
            }
            System.out.println("RESPONSE");
            System.out.println(connection.getResponseCode());
            System.out.println(connection.getResponseMessage());
            System.out.println(response.get(0));
        } catch (IOException e) {
            e.printStackTrace();
        }
        return response.get(0);
    }


    //Certificate config
    @Override
    public void checkClientTrusted(X509Certificate[] arg0, String arg1) {
    }

    @Override
    public void checkServerTrusted(X509Certificate[] arg0, String arg1) {
    }

    @Override
    public X509Certificate[] getAcceptedIssuers() {
        return null;
    }

}
