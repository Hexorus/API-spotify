package utils;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import io.github.cdimascio.dotenv.Dotenv;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;


public class XrayUtil {
    //ENVS
    private static Dotenv ENV ;
    //PATHS
    private static final String ROOT_PATH_FEATURES = "src/test/java/taller/features";
    private static final String PATH_ZIP_FEATURES = "features.zip";
    //KEYS
    //private static String TEST_PLAN_KEY = System.getenv("TestPlanKey");
    //private static String COMPONENTS = System.getenv("Components");
    // XRAY
    private static String XRAY_URL;
    private static String XRAY_CLIENT_ID;
    private static String XRAY_CLIENT_SECRET;
    private static String XRAY_PROJECT_ID;
    private static String XRAY_TEST_EXECUTION_TYPE_ID;
    private static String XRAY_PROJECT_KEY;
    private static String XRAY_TEST_PLAN_KEY;
    private static String XRAY_COMPONENTS;
    private static String XRAY_COMPONENT;
    private static String XRAY_HOOK_CHECK_AUTOMATIZADOS;


    private static final String TOKEN_PATH = "authenticate";
    private static String TOKEN_XRAY = "";
    //SINCRONIZACION DE FEATURES
    private static final String IMPORT_FEATURES_PATH = "import/feature?projectKey=";
    private static String RESPONSE_SINC;
    // Unificacion de reportes
    private static final String ROOT_PATH_REPORTS_JSON = "target/karate-reports";
    private static final String IMPORT_EXECUTION_PATH = "import/execution/cucumber/multipart";
    private static final String PATH_UNIFED_REPORT_JSON = "result.json";
    private static final String PATH_METADATA_INFO_JSON = "info.json";

    public static void cargarVariablesDeAmbiente() {
        //get variable enviroment env or set 'qa' as default

        if (System.getenv("XRAY_CLIENT_ID") == null) {
            String env = System.getenv("KARATE_ENV");
            if (env == null) {
                env = "qa";
            }

            Dotenv dotenv = null;
            dotenv = Dotenv.configure()
                    .directory(System.getProperty("user.dir") + "/src/test/java/envs")
                    .filename(".env." + env).load();

            System.out.println(String.format(
                    "Variables de ambiente cargadas: %s", System.getProperty("user.dir") + "/envs" + "/.env." + env));
            ENV = dotenv;
            XRAY_URL = ENV.get("XRAY_URL");
            XRAY_CLIENT_ID = ENV.get("XRAY_CLIENT_ID");
            XRAY_CLIENT_SECRET = ENV.get("XRAY_CLIENT_SECRET");
            XRAY_PROJECT_ID = ENV.get("XRAY_PROJECT_ID");
            XRAY_TEST_EXECUTION_TYPE_ID = ENV.get("XRAY_TEST_EXECUTION_TYPE_ID");
            XRAY_PROJECT_KEY = ENV.get("XRAY_PROJECT_KEY");
            XRAY_TEST_PLAN_KEY = ENV.get("XRAY_TEST_PLAN_KEY");
            XRAY_COMPONENTS = ENV.get("XRAY_COMPONENT");
            XRAY_HOOK_CHECK_AUTOMATIZADOS = ENV.get("XRAY_HOOK_CHECK_AUTOMATIZADOS");

        } else {
            XRAY_URL = System.getenv("XRAY_URL");
            XRAY_CLIENT_ID = System.getenv("XRAY_CLIENT_ID");
            XRAY_CLIENT_SECRET = System.getenv("XRAY_CLIENT_SECRET");
            XRAY_PROJECT_ID = System.getenv("XRAY_PROJECT_ID");
            XRAY_TEST_EXECUTION_TYPE_ID = System.getenv("XRAY_TEST_EXECUTION_TYPE_ID");
            XRAY_PROJECT_KEY = System.getenv("XRAY_PROJECT_KEY");
            XRAY_TEST_PLAN_KEY = System.getenv("XRAY_TEST_PLAN_KEY");
            XRAY_COMPONENTS = System.getenv("XRAY_COMPONENT");
            XRAY_HOOK_CHECK_AUTOMATIZADOS = System.getenv("XRAY_HOOK_CHECK_AUTOMATIZADOS");
        }

    }

    public static void sincronizarFetaures() throws Exception {
        Path dirComponents = Paths.get(System.getProperty("user.dir")).resolve(ROOT_PATH_FEATURES);
        Path dirZipFeatures = Paths.get(System.getProperty("user.dir")).resolve(PATH_ZIP_FEATURES);

        //Busca todos los archivos feature en el @rootPathFeatures y filtra los que no son reutilizables
        Stream<Path> allValidFeaturesFiles = Files.walk(dirComponents).filter(path -> isValidFeature(path.toFile()));

        //Genera un archivo zip con todos los archivos features allValidFeatures
        List<String> allPathsFetaures = allValidFeaturesFiles.map(path -> path.toFile().getAbsolutePath()).collect(Collectors.toList());
        zipFiles(allPathsFetaures);

        //Se obtiene token
        TOKEN_XRAY = getTokenXray().replace("\n", "").replaceAll("^\"|\"$", "");

        //Sincronizacion de features en jira-xray
        //Todos los scenarios y backgrounds deben tener como tags su respectivo id de jira
        try {
            MultipartUtility multipartUtility = new MultipartUtility(XRAY_URL + IMPORT_FEATURES_PATH + XRAY_PROJECT_KEY, "utf-8", null, TOKEN_XRAY);
            multipartUtility.addFilePart("file", dirZipFeatures.toFile());
            RESPONSE_SINC = multipartUtility.finish();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Unifica todos los reportes.json generados en karate-reports y los unifica en un solo archivo
     *
     * @throws Exception
     */
    public static void unficarReportesJson() throws Exception {
        Path dirKarateReports = Paths.get(System.getProperty("user.dir")).resolve(ROOT_PATH_REPORTS_JSON);
        List<String> allValidReports = Files.list(dirKarateReports)
                .filter(path -> path.toFile().getAbsolutePath().endsWith(".json"))
                .map(path -> path.toFile().getAbsolutePath()).toList();

        System.out.printf("Se encontraron %s reportes\n", allValidReports.size());

        JSONArray reporteUnificado = new JSONArray();
        ;
        allValidReports.stream().forEach(path -> {
            try {
                reporteUnificado.add(JsonUtil.readJsonArray(path).get(0));
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        });
        JsonUtil.writeJson(reporteUnificado, PATH_UNIFED_REPORT_JSON);
    }


    public static void generarInfoJson() throws IOException, ParseException {
        System.out.println("Generando info.json");

        // creating JSONObject
        JSONObject infojson = new JSONObject();
        Map fields = new LinkedHashMap(4);
        Map project = new LinkedHashMap(1);
        String summary = new String();
        Map issueType = new LinkedHashMap(1);
        JSONArray componentsJsonArray = new JSONArray();
        Map xrayFields = new LinkedHashMap(1);
        JSONArray environments = new JSONArray();

        //COMPONENTS = ENV.get("XRAY_COMPONENTS_LIST");
        //COMPONENTS = null;

        //TEST_PLAN_KEY = ENV.get("XRAY_TEST_PLAN_KEY");

        //Summary
        SimpleDateFormat simpleDateFormat  = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        String date = simpleDateFormat.format(new Date());


        project.put("id", XRAY_PROJECT_ID);
        issueType.put("id", XRAY_TEST_EXECUTION_TYPE_ID);

        //summary
        String componentSummary = "";
        if (XRAY_COMPONENTS != null) {
            String[] componentsAsArray = XRAY_COMPONENTS.split(",");
            //components
            List<Map> temp_components = new ArrayList<>();
            for (int i = 0; i < componentsAsArray.length; i++) {
                System.out.println(componentsAsArray[i]);
                temp_components.add(new LinkedHashMap(1));
                temp_components.get(i).put("name", componentsAsArray[i]);
                componentsJsonArray.add(temp_components.get(i));
            }
            fields.put("components", componentsJsonArray);
            componentSummary = Arrays.toString(componentsAsArray);
            summary = String.format("Test execution de componentes %s del %s", componentSummary, date);
        } else if (XRAY_COMPONENT != null) {
            List<Map> temp_components = new ArrayList<>();
            temp_components.add(new LinkedHashMap(1));
            temp_components.get(0).put("name", XRAY_COMPONENT);
            componentsJsonArray.add(temp_components.get(0));
            fields.put("components", componentsJsonArray);
            componentSummary = XRAY_COMPONENT;
            summary = String.format("Test execution de componentes %s del %s", componentSummary, date);
        } else {
            summary = String.format("Test execution regresión del %s", date);
        }


        //Aramado de json final
        fields.put("project", project);
        fields.put("summary", summary);
        fields.put("issuetype", issueType);
        //if TEST_PLAN_KEY is not empty
        if (XRAY_TEST_PLAN_KEY != null) {
            xrayFields.put("testPlanKey", XRAY_TEST_PLAN_KEY);
        }

        if (System.getenv("KARATE_ENV") == null) {
            environments.add("QA");
        } else {
            environments.add(System.getenv("KARATE_ENV").toUpperCase());
        }

        xrayFields.put("environments", environments);
        infojson.put("fields", fields);
        infojson.put("xrayFields", xrayFields);

        JsonUtil.writeJson(infojson, PATH_METADATA_INFO_JSON);
    }

    public static void enviarReporte() {
        System.out.printf("Enviando reporte a Xray\n");
        try {
            MultipartUtility multipartUtility = new MultipartUtility(XRAY_URL + IMPORT_EXECUTION_PATH, "utf-8", null, TOKEN_XRAY);//FALTA TOKEN_XRAY
            multipartUtility.addFilePart("results", Paths.get(PATH_UNIFED_REPORT_JSON).toFile());
            multipartUtility.addFilePart("info", Paths.get(PATH_METADATA_INFO_JSON).toFile());
            String response = multipartUtility.finish();
            System.out.println(response);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    /**
     * Muestra el path absoluto del @file
     *
     * @param file *.feature
     */
    public static void showFile(File file) {
        if (isValidFeature(file)) {
            System.out.println("file: " + file.getAbsolutePath());
        }
    }


    /**
     * Filtra los archivos *.feature y que no estan en la carpeta reusable
     *
     * @param file archivo o directorio
     * @return True si es un archivo, si su path contiene 'feature' y no contiene 'reusable'
     */
    public static Boolean isValidFeature(File file) {
        return (file.isFile() && file.getAbsolutePath().contains(".feature") && !file.getAbsolutePath().contains("reusable"));
    }


    /**
     * Comprime en un archivo zip todos los archivos en la lista srctFiles
     *
     * @param srcFiles Lista de rutas de archivos
     * @throws IOException
     */
    public static void zipFiles(List<String> srcFiles) throws IOException {
        FileOutputStream fos = new FileOutputStream("features.zip");
        ZipOutputStream zipOut = new ZipOutputStream(fos);
        for (String srcFile : srcFiles) {
            File fileToZip = new File(srcFile);
            FileInputStream fis = new FileInputStream(fileToZip);
            ZipEntry zipEntry = new ZipEntry(fileToZip.getName());
            zipOut.putNextEntry(zipEntry);

            byte[] bytes = new byte[1024];
            int length;
            while ((length = fis.read(bytes)) >= 0) {
                zipOut.write(bytes, 0, length);
            }
            fis.close();
        }
        zipOut.close();
        fos.close();
    }


    /**
     * Obtiene el token de autorizacion en Xray
     *
     * @return token de autorizacion
     * @throws Exception
     */
    public static String getTokenXray() throws Exception {
        System.out.println("Obteniendo token de autorizacion en Xray");

        var values = new HashMap<String, String>() {{
            put("client_id", XRAY_CLIENT_ID);
            put("client_secret", XRAY_CLIENT_SECRET);
        }};
        var objectMapper = new ObjectMapper();
        String requestBody = objectMapper
                .writeValueAsString(values);
        return ApiUtil.post(XRAY_URL + TOKEN_PATH, requestBody);
    }

    /**
     * A partir del response de sincronizarFeatures, obtiene todos los keys del response y los envia al hook para actualizar el flag "Automatizado" en jira
     * @throws Exception
     */
    public static void marcarCasosAutomatizados() throws Exception {
        JSONParser parser = new JSONParser();
        JSONObject responseJson = ((JSONObject) parser.parse(RESPONSE_SINC));
        JSONArray updatedTestsJira = (JSONArray) responseJson.get("updatedOrCreatedTests");
        JSONArray updatedPreconditionsJira = (JSONArray) responseJson.get("updatedOrCreatedPreconditions");

        //Concatena ambos JsonArrays en uno
        for (int i = 0; i < updatedPreconditionsJira.size(); i++) {
            updatedTestsJira.add(updatedPreconditionsJira.get(i));
        }

        // filtra los keys de los tests que se han actualizado
        List<String> keysTestsJira = updatedTestsJira.stream().map((test) -> {
            return ((JSONObject) test).get("key").toString();
        }).toList();

        //crea el objeto que se va a enviar al hook
        JSONObject keysToProcess = new JSONObject();
        //add list keys to jsonObject
        keysToProcess.put("issues", keysTestsJira);

        //Envia el objeto al hook
        ApiUtil.post(XRAY_HOOK_CHECK_AUTOMATIZADOS, keysToProcess.toJSONString());
    }

}

