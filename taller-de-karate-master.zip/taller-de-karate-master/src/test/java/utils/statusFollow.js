validarCode = (code) =>{
    switch(code){
        case 200:
            return null;
            break;
        case 204:
            return null;
            break;
        case 404:
            return null;
            break;
        default:
            return response.error.message;
            break;
    }
}
