package utils.dataBase;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;


public class DbUtils {

    private static final Logger logger = LoggerFactory.getLogger(DbUtils.class);

    private final JdbcTemplate jdbc;
    private final DriverManagerDataSource dataSource;

    public DbUtils(Map<String, Object> config) {
        String url = (String) config.get("url");
        String username = (String) config.get("username");
        String password = (String) config.get("password");
        String driver = (String) config.get("driverClassName");
        dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driver);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        jdbc = new JdbcTemplate(dataSource);

        logger.info("init jdbc template: {}", url);
    }

    /**
     * Ejecuta @query de tipo Select y luego cierra la conexion
     * @param query de tipo select que devuelva un solo valor(celda)
     * @return un objeto que contiene el valor del select
     * @throws SQLException
     */
    public Object readValue(String query) throws SQLException {
        Object result = jdbc.queryForObject(query, Object.class);
        dataSource.getConnection().close();
        return result;
    }

    /**
     * Ejecuta @query de tipo Select y luego cierra la conexion
     * @param query  de tipo select que devuelva una fila
     * @return Un objeto de tipo clave(columna):valor(celda)
     * @throws SQLException
     */
    public Map<String, Object> readRow(String query) throws SQLException {
        Map<String, Object> row = jdbc.queryForMap(query);
        dataSource.getConnection().close();
        return row;
    }

    /**
     * Ejecuta @query de tipo Select y luego cierra la conexion
     * @param query de tipo select que devuelva mas de una fila
     * @return Una lista de objetos tipo clave(columna):valor(celda), donde cada elemento de la lista es una fila.
     * @throws SQLException
     */
    public List<Map<String, Object>> readRows(String query) throws SQLException {
        List<Map<String, Object>> rows = jdbc.queryForList(query);
        dataSource.getConnection().close();
        return rows;
    }


    /**
     * Ejecuta @query de tipo update,insert o delete y luego cierra la conexion
     * @param query Update,Insert,Delete
     * @return la cantidad de filas afectadas
     * @throws SQLException
     */
    public int update(String query) throws SQLException {
        int rowsAffected = jdbc.update(query);
        dataSource.getConnection().close();
        return rowsAffected;
    }

}