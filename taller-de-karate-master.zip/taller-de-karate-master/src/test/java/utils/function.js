function(url){

return url.split("access_token=")[1].split("&")[0];
}

