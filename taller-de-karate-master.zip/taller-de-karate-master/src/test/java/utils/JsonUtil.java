package utils;

import org.json.simple.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class JsonUtil {

    /**
     *
     * @param object Json de tipo JSONObject
     * @return json en formato diccionario o Map<String,Object>
     * @throws JSONException
     */
    public static Map<String, Object> toMap(JSONObject object) throws JSONException {
        Map<String, Object> map = new HashMap<String, Object>();

        Iterator<String> keysItr = object.keys();
        while(keysItr.hasNext()) {
            String key = keysItr.next();
            Object value = object.get(key);

            if(value instanceof JSONArray) {
                value = toList((JSONArray) value);
            }

            else if(value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            map.put(key, value);
        }
        return map;
    }

    public static List<Object> toList(JSONArray array) throws JSONException {
        List<Object> list = new ArrayList<Object>();
        for(int i = 0; i < array.size(); i++) {
            Object value = array.get(i);
            if(value instanceof JSONArray) {
                value = toList((JSONArray) value);
            }

            else if(value instanceof JSONObject) {
                value = toMap((JSONObject) value);
            }
            list.add(value);
        }
        return list;
    }


    /**
     *
     * @param jsonAsString String en formato JSON
     * @return json en formato diccionario o Map<String,Object>
     * @throws JSONException
     */
    public static Map<String, Object> jsonToMap(String jsonAsString) throws JSONException {
        Map<String, Object> retMap = new HashMap<String, Object>();
        JSONObject json = new JSONObject(jsonAsString);
        if(!json.equals(JSONObject.NULL)) {
            retMap = toMap(json);
        }
        return retMap;
    }

    /**
     *
     * @param path ruta del json que comienza con []
     * @return JsonArray
     * @throws JSONException
     * @throws IOException
     * @throws ParseException
     */
    public static JSONArray readJsonArray(String path) throws JSONException, IOException, ParseException {
        Object obj = new JSONParser().parse(new FileReader(path));
        return (JSONArray) obj;
    }

    /**
     *  Escribe un json que comineza como un array en @pathJson
     * @param jsonArray de tipo [{}]
     * @throws JSONException
     * @throws IOException
     * @throws ParseException
     */
    public static void writeJson(JSONArray jsonArray, String pathJson) throws JSONException, IOException, ParseException {
        PrintWriter pw = new PrintWriter(pathJson);
        pw.write(jsonArray.toJSONString());
        pw.flush();
        pw.close();
    }

    /**
     *  Escribe un json en @pathJson
     * @param json de tipo {}
     * @throws JSONException
     * @throws IOException
     * @throws ParseException
     */
    public static void writeJson(org.json.simple.JSONObject json, String pathJson) throws JSONException, IOException, ParseException {
        PrintWriter pw = new PrintWriter(pathJson);
        pw.write(json.toJSONString());
        pw.flush();
        pw.close();
    }
}
