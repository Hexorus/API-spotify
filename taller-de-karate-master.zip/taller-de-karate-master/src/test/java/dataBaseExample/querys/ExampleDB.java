package dataBaseExample.querys;
import utils.dataBase.DbUtils;
import java.io.IOException;
import java.net.URISyntaxException;
import java.sql.SQLException;
import java.util.Map;
import utils.util;
import utils.JsonUtil;

/**
 * ExampleDB es una clase intermedia entre el feature y la DBUtils.
 * Esta clase sirve para estructurar mejor las consultas a base de datos, permitiendo reutilizarlas parametrizandolas
 *  y evitando no harcodear las consultas en el feature.
 *  Se recomienda hacer una de estas clases intermedias por cada funcionalidad o tabla que se necesite
 */
public class ExampleDB {

    private final DbUtils utilDb;

    /**
     * Constructor donde se leen las credenciales de la DB y se instancia DBUtils para hacer la conexion
     * @throws URISyntaxException
     * @throws IOException
     */
    public ExampleDB() throws URISyntaxException, IOException {
        // Lee el archivo de las credenciales
        String jsonCredentials = util.readFileFromResources("utils/dataBase/dataBaseConfig.json");
        //Convierte el string en un diccionario valido para la instancia de Dbutils
        Map<String, Object> config = JsonUtil.jsonToMap(jsonCredentials);
        //Se inicia la conexion a la base de datos con las credenciales de "OracleDataBaseName" indicadas en dataBaseConfig.json
        utilDb = new DbUtils((Map<String, Object>) config.get("OracleDataBaseName"));
    }

    /**
     * Ejemplo de consulta
     * @param parametro
     * @return la fila consultado en formato json
     * @throws SQLException
     */
    public Map<String, Object> consultarUnaFila(String parametro) throws SQLException {
        String query = String.format("SELECT COLUMNA1, COLUMNA2,COLUMNA3 FROM TABLA WHERE COLUMNA1 = %s",parametro);
        return utilDb.readRow(query);

    }

    /**
     *
     * @param parametroDeReferencia
     * @param nuevoValor
     * @return la cantidad de filas afectadas
     * @throws SQLException
     */
    public int actualizarUnCampo(String parametroDeReferencia,String nuevoValor) throws SQLException {
        String query = String.format("UPDATE TABLA SET COLUMNA1 = '%s' WHERE COLUMNA2 = %s",nuevoValor,parametroDeReferencia);
        return utilDb.update(query);
    }



}
