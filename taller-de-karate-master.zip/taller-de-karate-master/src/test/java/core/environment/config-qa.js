function environmentQA() {

	var ambiente = {
	    username: 'merce.baufest@gmail.com',
        password: 'Baufest123#',
	    code: '4c9c6c66038e46fea9c127a5a04a72c6',
		url: 'https://petstore.swagger.io',
		browser: 'https://api.spotify.com/v1/browse',
		currentUser: 'https://api.spotify.com/v1/me',
		follow: 'https://api.spotify.com/v1/me/following',
        Fplaylist: 'https://api.spotify.com/v1/playlists',
        Following: 'https://api.spotify.com/v1/me/following/contains',
        audioAnalysis: 'https://api.spotify.com/v1/audio-analysis/',
        audioFeatures: 'https://api.spotify.com/v1/audio-features',
        tracks: 'https://api.spotify.com/v1/tracks',
        personalization: 'https://api.spotify.com/v1/me/top',
        search: 'https://api.spotify.com/v1/search?',
        shows: 'https://api.spotify.com/v1/me/shows',
        playlist: 'https://api.spotify.com/v1/playlists/',
        mePlaylist: 'https://api.spotify.com/v1/me/playlists',
        artist: 'https://api.spotify.com/v1/artists/',
        usersprofile: 'https://api.spotify.com/v1/users/',
        browse: 'https://api.spotify.com/v1/browse/',
        scopeFollowLibrary: 'playlist-modify-public%2Cplaylist-modify-private%2Cplaylist-read-private%2Cuser-follow-modify%2Cuser-follow-read%2Cuser-top-read%2Cuser-library-modify%2Cuser-library-read',
        NewReleases: 'https://api.spotify.com/v1/browse/new-releases',
        Recommendations: 'https://api.spotify.com/v1/recommendations',
        episodes: 'https://api.spotify.com/v1/episodes',
        market: 'https://api.spotify.com/v1/markets'
	};



	// Feature API Ejemplo
	ambiente.flujoX = {
		user : {
			numero_celular : '+5491177361162',
			dni : '71452242',
			password : '115599'
		},
		cards : {
			visa_debit_card_token : '4123220000000016',
			visa_credit_card : '4540750039904452',
			visa_debit_card : '4517650612965467',
			master_credit_card : '5505688230915366',
			master_debit_card : '5142850020531006',
			amex_credit_card : '371593210378043',
			cabal_credit_card : '6042011000007025'
		}
	}

	return ambiente;
}