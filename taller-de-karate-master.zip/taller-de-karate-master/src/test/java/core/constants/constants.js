function fn() {

	var constants = {};

	// User Status
	constants.user_status = {
		active : 1,
		inactive : 0
	}
	
	// Json Path
	constants.create_pet = {
		request : 'request/create_pet.json',
		response : 'response/create_pet.json'
	}
	
	constants.create_user = {
		request : 'request/create_user.json',
		response : 'response/create_user.json'
	}
	
	constants.get_pet = {
		response : 'response/get_pet.json'
	}
	
	constants.get_user = {
		response : 'response/get_user.json'
	}
	
	constants.get_user_2 = {
		response : 'response/get_user_2.json'
	}

	return constants;
}
